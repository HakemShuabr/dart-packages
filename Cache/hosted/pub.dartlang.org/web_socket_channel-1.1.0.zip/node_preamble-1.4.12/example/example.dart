import "package:node_preamble/preamble.dart" as preamble;

main() {
  print(preamble.getPreamble());
}
