// Copyright (c) 2018, Anatoly Pulyaevskiy. All rights reserved. Use of this source code
// is governed by a BSD-style license that can be found in the LICENSE file.

/// Yes, there is no need to import anything to get this working.
void main() {
  print('Hello World!');
}
